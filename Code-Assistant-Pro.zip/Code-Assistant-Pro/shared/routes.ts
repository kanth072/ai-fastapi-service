
import { z } from 'zod';
import { insertImageSchema, insertAudioSchema, processedImages, audioTranscriptions } from './schema';

// Shared error schemas
export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  images: {
    process: {
      method: 'POST' as const,
      path: '/api/images/process' as const,
      // Input is FormData (not strictly typed here but handled in backend)
      responses: {
        200: z.object({
          status: z.literal("success"),
          original_image: z.string(),
          generated_images: z.array(z.string())
        }),
        500: errorSchemas.internal
      }
    },
    list: {
      method: 'GET' as const,
      path: '/api/images' as const,
      responses: {
        200: z.array(z.custom<typeof processedImages.$inferSelect>())
      }
    }
  },
  audio: {
    transcribe: {
      method: 'POST' as const,
      path: '/api/audio/transcribe' as const,
      // Input is FormData
      responses: {
        200: z.object({
          status: z.literal("success"),
          transcribed_text: z.string(),
          language: z.string().optional()
        }),
        500: errorSchemas.internal
      }
    },
    list: {
      method: 'GET' as const,
      path: '/api/audio' as const,
      responses: {
        200: z.array(z.custom<typeof audioTranscriptions.$inferSelect>())
      }
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
