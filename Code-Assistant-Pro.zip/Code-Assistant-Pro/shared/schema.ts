
import { pgTable, text, serial, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===
export const processedImages = pgTable("processed_images", {
  id: serial("id").primaryKey(),
  originalUrl: text("original_url").notNull(),
  variations: jsonb("variations").notNull(), // Stores array of generated image URLs
  createdAt: timestamp("created_at").defaultNow(),
});

export const audioTranscriptions = pgTable("audio_transcriptions", {
  id: serial("id").primaryKey(),
  audioUrl: text("audio_url").notNull(),
  transcribedText: text("transcribed_text").notNull(),
  language: text("language"),
  createdAt: timestamp("created_at").defaultNow(),
});

// === SCHEMAS ===
export const insertImageSchema = createInsertSchema(processedImages).omit({ 
  id: true, 
  createdAt: true 
});

export const insertAudioSchema = createInsertSchema(audioTranscriptions).omit({ 
  id: true, 
  createdAt: true 
});

// === EXPLICIT API TYPES ===
export type ProcessedImage = typeof processedImages.$inferSelect;
export type InsertProcessedImage = z.infer<typeof insertImageSchema>;

export type AudioTranscription = typeof audioTranscriptions.$inferSelect;
export type InsertAudioTranscription = z.infer<typeof insertAudioSchema>;

// Response types
export interface ImageProcessingResponse {
  status: "success" | "error";
  original_image: string;
  generated_images: string[];
}

export interface AudioProcessingResponse {
  status: "success" | "error";
  transcribed_text: string;
  language: string;
}
