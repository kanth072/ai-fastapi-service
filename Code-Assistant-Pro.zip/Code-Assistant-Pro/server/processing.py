
import uvicorn
from fastapi import FastAPI, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
import cv2
import numpy as np
from PIL import Image, ImageEnhance, ImageFilter
import io
import base64
import os
import logging
import json

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def image_to_base64(image):
    _, buffer = cv2.imencode('.jpg', image)
    return base64.b64encode(buffer).decode('utf-8')

def pil_to_base64(image):
    buffered = io.BytesIO()
    image.save(buffered, format="JPEG")
    return base64.b64encode(buffered.getvalue()).decode('utf-8')

def process_image_variations(image_bytes):
    # Decode image
    nparr = np.frombuffer(image_bytes, np.uint8)
    original_cv = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    original_pil = Image.open(io.BytesIO(image_bytes))
    
    variations = []
    
    # 1. Original (for reference, though we return the uploaded one usually)
    # variations.append(image_to_base64(original_cv))

    # 2. Slight Left Angle (Perspective Warping)
    rows, cols, ch = original_cv.shape
    pts1 = np.float32([[50, 50], [200, 50], [50, 200]])
    pts2 = np.float32([[10, 100], [200, 50], [100, 250]])
    M = cv2.getAffineTransform(pts1, pts2)
    left_angle = cv2.warpAffine(original_cv, M, (cols, rows))
    variations.append("data:image/jpeg;base64," + image_to_base64(left_angle))

    # 3. Slight Right Angle
    pts1 = np.float32([[50, 50], [200, 50], [50, 200]])
    pts2 = np.float32([[50, 50], [240, 100], [50, 200]])
    M = cv2.getAffineTransform(pts1, pts2)
    right_angle = cv2.warpAffine(original_cv, M, (cols, rows))
    variations.append("data:image/jpeg;base64," + image_to_base64(right_angle))

    # 4. Zoomed Portrait Crop (Center Crop)
    center_x, center_y = cols // 2, rows // 2
    crop_w, crop_h = int(cols * 0.6), int(rows * 0.6)
    x1 = max(0, center_x - crop_w // 2)
    y1 = max(0, center_y - crop_h // 2)
    x2 = min(cols, x1 + crop_w)
    y2 = min(rows, y1 + crop_h)
    cropped = original_cv[y1:y2, x1:x2]
    variations.append("data:image/jpeg;base64," + image_to_base64(cropped))

    # 5. Background Blur (Simple Gaussian Blur on edges - Mocking portrait mode)
    # Real portrait mode requires segmentation, here we'll just blur the whole thing slightly for effect
    blurred = original_pil.filter(ImageFilter.GaussianBlur(radius=3))
    variations.append("data:image/jpeg;base64," + pil_to_base64(blurred))

    # 6. Light Enhancement (Contrast + Brightness)
    enhancer = ImageEnhance.Contrast(original_pil)
    enhanced = enhancer.enhance(1.5) # Increase contrast
    enhancer = ImageEnhance.Brightness(enhanced)
    final_enhanced = enhancer.enhance(1.2) # Increase brightness
    variations.append("data:image/jpeg;base64," + pil_to_base64(final_enhanced))

    return variations

# --- Audio Processing ---
import whisper
import tempfile

# Load model globally to avoid reloading on every request
# Using "base" model as requested
print("Loading Whisper model...")
audio_model = whisper.load_model("base")
print("Whisper model loaded.")

@app.post("/process/audio")
async def process_audio_endpoint(file: UploadFile = File(...)):
    try:
        # Save uploaded file to a temporary file
        suffix = os.path.splitext(file.filename)[1]
        if not suffix:
            suffix = ".webm" # Default for browser MediaRecorder blobs
        
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            content = await file.read()
            tmp.write(content)
            tmp_path = tmp.name

        # Transcribe with task="translate" to force English output
        result = audio_model.transcribe(tmp_path, task="translate")
        
        # Cleanup
        os.unlink(tmp_path)

        raw_text = result["text"].strip()
        
        # Professional Formatting for E-commerce
        formatted_text = "📦 PRODUCT ANALYSIS REPORT\n"
        formatted_text += "━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
        
        sections = raw_text.split(". ")
        for i, section in enumerate(sections):
            if i == 0:
                formatted_text += f"🏷️ SUMMARY: {section}.\n\n"
            elif any(word in section.lower() for word in ["price", "cost", "dollar", "rupee", "amount"]):
                formatted_text += f"💰 PRICING: {section}.\n\n"
            elif any(word in section.lower() for word in ["feature", "function", "spec", "quality", "detail"]):
                formatted_text += f"✨ FEATURES: {section}.\n\n"
            else:
                formatted_text += f"📝 DETAIL: {section}.\n\n"

        formatted_text += "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        formatted_text += f"🌍 SOURCE LANGUAGE: {result['language'].upper()}\n"
        formatted_text += "✅ TRANSLATION: STRICT ENGLISH"

        return {
            "status": "success",
            "transcribed_text": formatted_text,
            "language": result["language"],
            "duration": result.get("segments", [{}])[-1].get("end", 0) if result.get("segments") else 0
        }
    except Exception as e:
        logger.error(f"Error processing audio: {str(e)}")
        return {"status": "error", "message": str(e)}

@app.post("/process/image")
async def process_image_endpoint(file: UploadFile = File(...)):
    contents = await file.read()
    
    try:
        variations = process_image_variations(contents)
        
        return {
            "status": "success",
            "original_image": "data:image/jpeg;base64," + base64.b64encode(contents).decode('utf-8'),
            "generated_images": variations
        }
    except Exception as e:
        logger.error(f"Error processing image: {str(e)}")
        return {"status": "error", "message": str(e)}

@app.get("/health")
def health_check():
    return {"status": "ok"}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=5001)
