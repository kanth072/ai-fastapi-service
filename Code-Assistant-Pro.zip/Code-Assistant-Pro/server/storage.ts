
import { 
  processedImages, audioTranscriptions,
  type InsertProcessedImage, type InsertAudioTranscription,
  type ProcessedImage, type AudioTranscription
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  createProcessedImage(image: InsertProcessedImage): Promise<ProcessedImage>;
  getProcessedImages(): Promise<ProcessedImage[]>;
  createAudioTranscription(audio: InsertAudioTranscription): Promise<AudioTranscription>;
  getAudioTranscriptions(): Promise<AudioTranscription[]>;
}

export class DatabaseStorage implements IStorage {
  async createProcessedImage(image: InsertProcessedImage): Promise<ProcessedImage> {
    const [newImage] = await db.insert(processedImages).values(image).returning();
    return newImage;
  }

  async getProcessedImages(): Promise<ProcessedImage[]> {
    return await db.select().from(processedImages).orderBy(processedImages.createdAt);
  }

  async createAudioTranscription(audio: InsertAudioTranscription): Promise<AudioTranscription> {
    const [newAudio] = await db.insert(audioTranscriptions).values(audio).returning();
    return newAudio;
  }

  async getAudioTranscriptions(): Promise<AudioTranscription[]> {
    return await db.select().from(audioTranscriptions).orderBy(audioTranscriptions.createdAt);
  }
}

export const storage = new DatabaseStorage();
