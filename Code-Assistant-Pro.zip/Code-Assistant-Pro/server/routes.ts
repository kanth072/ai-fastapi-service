
import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import axios from "axios";
import FormData from "form-data";
import fs from "fs";
import path from "path";

const upload = multer({ dest: "uploads/" });

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // Ensure uploads directory exists
  if (!fs.existsSync("uploads")) {
    fs.mkdirSync("uploads");
  }

  // --- Image Processing Route ---
  app.post(api.images.process.path, upload.single('image'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No image file provided" });
      }

      // Forward to Python service
      const formData = new FormData();
      formData.append('file', fs.createReadStream(req.file.path), req.file.originalname);

      // Retry connection to Python service a few times if it's just starting up
      let retries = 5;
      let response;
      while (retries > 0) {
        try {
          response = await axios.post('http://127.0.0.1:5001/process/image', formData, {
            headers: {
              ...formData.getHeaders(),
            },
          });
          break;
        } catch (error) {
          retries--;
          if (retries === 0) throw error;
          await new Promise(resolve => setTimeout(resolve, 1000));
        }
      }

      if (!response || response.data.status === 'error') {
        throw new Error(response?.data?.message || "Processing failed");
      }

      const { original_image, generated_images } = response.data;

      // Save to DB
      const processed = await storage.createProcessedImage({
        originalUrl: original_image, // Storing base64 directly for simplicity in this MVP
        variations: generated_images,
      });

      // Cleanup uploaded file
      fs.unlinkSync(req.file.path);

      res.json({
        status: "success",
        original_image: processed.originalUrl,
        generated_images: processed.variations as string[]
      });

    } catch (error: any) {
      console.error("Image processing error:", error.message);
      if (req.file && fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
      res.status(500).json({ message: "Internal server error: " + error.message });
    }
  });

  app.get(api.images.list.path, async (req, res) => {
    const images = await storage.getProcessedImages();
    res.json(images);
  });

  // --- Audio Transcription Route ---
  app.post(api.audio.transcribe.path, upload.single('audio'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No audio file provided" });
      }

      const formData = new FormData();
      formData.append('file', fs.createReadStream(req.file.path), req.file.originalname);

      // Call Python service
      let retries = 5;
      let response;
      while (retries > 0) {
        try {
          response = await axios.post('http://127.0.0.1:5001/process/audio', formData, {
            headers: { ...formData.getHeaders() },
          });
          break;
        } catch (error) {
          retries--;
          if (retries === 0) throw error;
          await new Promise(resolve => setTimeout(resolve, 1000));
        }
      }

      if (!response || response.data.status === 'error') {
        throw new Error(response?.data?.message || "Transcription failed");
      }

      const { transcribed_text, language, duration } = response.data;

      // Save to DB
      const transcription = await storage.createAudioTranscription({
        audioUrl: "recorded_audio",
        transcribedText: transcribed_text,
        language: language || "unknown",
      });

      // Cleanup
      fs.unlinkSync(req.file.path);

      res.json({
        status: "success",
        transcribed_text: transcription.transcribedText,
        language: transcription.language || undefined,
        duration_seconds: duration
      });

    } catch (error: any) {
      console.error("Audio processing error:", error.message);
      if (req.file && fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
      res.status(500).json({ message: "Internal server error: " + error.message });
    }
  });
  
  app.get(api.audio.list.path, async (req, res) => {
    const audios = await storage.getAudioTranscriptions();
    res.json(audios);
  });

  return httpServer;
}
