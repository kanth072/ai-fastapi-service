
# AI Full-Stack Application

A production-ready AI application featuring Image Processing, Audio Transcription, and Camera Integration.

## Project Structure

This project uses a hybrid architecture to combine the robustness of Node.js for the API gateway and the power of Python for AI processing.

```
project_root/
│
├── client/                 # Frontend (React + Vite)
│   ├── src/
│   │   ├── components/     # UI Components
│   │   ├── pages/          # Route pages
│   │   └── App.tsx         # Main entry
│   └── index.html
│
├── server/                 # Backend
│   ├── index.ts            # Node.js API Gateway & Process Manager
│   ├── routes.ts           # API Route Definitions
│   ├── processing.py       # Python AI Microservice (FastAPI)
│   ├── storage.ts          # Database Access Layer
│   └── requirements.txt    # Python Dependencies
│
├── shared/                 # Shared Code
│   ├── schema.ts           # Database Schema (Drizzle ORM)
│   └── routes.ts           # API Contracts (Zod)
│
└── uploads/                # Temporary file storage
```

## Features

1.  **Image Processing**:
    - Upload or capture images.
    - Automatic generation of 5 variations: Left/Right Angle, Zoom, Blur, Light Enhancement.
    - Powered by OpenCV and Pillow.

2.  **Audio Transcription**:
    - Upload audio files.
    - Transcribe text using OpenAI Whisper (local model).
    - Detect language.

3.  **Camera Integration**:
    - Live camera feed in browser.
    - Instant capture and processing.

## Setup & Installation

### Prerequisites
- Node.js v20+
- Python 3.11+
- PostgreSQL

### Installation

1.  **Install Node.js Dependencies:**
    ```bash
    npm install
    ```

2.  **Install Python Dependencies:**
    ```bash
    pip install -r server/requirements.txt
    ```
    *Note: In Replit, use the Packager tool or `uv` as configured.*

3.  **Database Setup:**
    Ensure `DATABASE_URL` is set, then push the schema:
    ```bash
    npm run db:push
    ```

### Running the Application

Start both the Node.js gateway and the Python AI service with a single command:

```bash
npm run dev
```

- **Frontend/API Gateway**: http://0.0.0.0:5000
- **Python Service**: http://127.0.0.1:5001 (Internal)

## Deployment

1.  **Build Frontend:**
    ```bash
    npm run build
    ```

2.  **Production Start:**
    Set `NODE_ENV=production` and run:
    ```bash
    npm start
    ```

## Testing

- **Image API**: `POST /api/images/process` (multipart/form-data, field `image`)
- **Audio API**: `POST /api/audio/transcribe` (multipart/form-data, field `audio`)
- **Health Check**: `GET /health` (Python service)
