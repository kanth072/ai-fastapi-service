import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";

// ============================================
// IMAGES
// ============================================

export function useImages() {
  return useQuery({
    queryKey: [api.images.list.path],
    queryFn: async () => {
      const res = await fetch(api.images.list.path);
      if (!res.ok) throw new Error("Failed to fetch images");
      return api.images.list.responses[200].parse(await res.json());
    },
  });
}

export function useProcessImage() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (formData: FormData) => {
      // Note: We don't JSON.stringify FormData
      const res = await fetch(api.images.process.path, {
        method: api.images.process.method,
        body: formData,
      });
      
      if (!res.ok) {
        const error = await res.json().catch(() => ({}));
        throw new Error(error.message || "Failed to process image");
      }
      
      return api.images.process.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.images.list.path] });
    },
  });
}

// ============================================
// AUDIO
// ============================================

export function useAudioTranscriptions() {
  return useQuery({
    queryKey: [api.audio.list.path],
    queryFn: async () => {
      const res = await fetch(api.audio.list.path);
      if (!res.ok) throw new Error("Failed to fetch transcriptions");
      return api.audio.list.responses[200].parse(await res.json());
    },
  });
}

export function useTranscribeAudio() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (formData: FormData) => {
      const res = await fetch(api.audio.transcribe.path, {
        method: api.audio.transcribe.method,
        body: formData,
      });

      if (!res.ok) {
        const error = await res.json().catch(() => ({}));
        throw new Error(error.message || "Failed to transcribe audio");
      }

      return api.audio.transcribe.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.audio.list.path] });
    },
  });
}
