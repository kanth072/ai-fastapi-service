import { Link, useLocation } from "wouter";
import { Camera, Mic, History, LayoutDashboard } from "lucide-react";
import { cn } from "@/lib/utils";

export function Sidebar() {
  const [location] = useLocation();

  const navItems = [
    { href: "/", label: "Dashboard", icon: LayoutDashboard },
    { href: "/studio", label: "Image Studio", icon: Camera },
    { href: "/transcriber", label: "Audio Transcriber", icon: Mic },
    { href: "/history", label: "History", icon: History },
  ];

  return (
    <aside className="w-64 h-screen border-r border-border bg-card/50 backdrop-blur-xl fixed left-0 top-0 z-40 hidden md:flex flex-col">
      <div className="p-8">
        <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
          MediaMind
        </h1>
        <p className="text-sm text-muted-foreground mt-1">AI Processing Suite</p>
      </div>

      <nav className="flex-1 px-4 space-y-2">
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href}>
              <div
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 cursor-pointer group",
                  isActive
                    ? "bg-primary text-primary-foreground shadow-lg shadow-primary/25"
                    : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                )}
              >
                <item.icon
                  className={cn(
                    "w-5 h-5 transition-transform duration-200",
                    !isActive && "group-hover:scale-110"
                  )}
                />
                <span className="font-medium">{item.label}</span>
              </div>
            </Link>
          );
        })}
      </nav>

      <div className="p-6 border-t border-border">
        <div className="bg-gradient-to-br from-primary/10 to-accent/10 rounded-xl p-4 border border-primary/10">
          <p className="text-xs font-medium text-primary mb-1">Pro Status</p>
          <p className="text-xs text-muted-foreground">Unlimited generations enabled.</p>
        </div>
      </div>
    </aside>
  );
}
