import { Upload, X, FileAudio, Image as ImageIcon } from "lucide-react";
import { useCallback, useState } from "react";
import { useDropzone } from "react-dropzone";
import { cn } from "@/lib/utils";

interface FileUploadProps {
  accept: Record<string, string[]>;
  onFileSelect: (file: File) => void;
  icon?: React.ElementType;
  label?: string;
}

export function FileUpload({ accept, onFileSelect, icon: Icon = Upload, label = "Upload File" }: FileUploadProps) {
  const [preview, setPreview] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      onFileSelect(file);
      setFileName(file.name);
      
      if (file.type.startsWith('image/')) {
        const url = URL.createObjectURL(file);
        setPreview(url);
      } else {
        setPreview(null);
      }
    }
  }, [onFileSelect]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept,
    maxFiles: 1
  });

  const clearFile = (e: React.MouseEvent) => {
    e.stopPropagation();
    setPreview(null);
    setFileName(null);
  };

  return (
    <div
      {...getRootProps()}
      className={cn(
        "relative rounded-xl border-2 border-dashed transition-all duration-200 cursor-pointer overflow-hidden group min-h-[160px] flex items-center justify-center",
        isDragActive 
          ? "border-primary bg-primary/5" 
          : "border-border hover:border-primary/50 hover:bg-secondary/50"
      )}
    >
      <input {...getInputProps()} />
      
      {preview ? (
        <div className="relative w-full h-full min-h-[200px]">
          <img 
            src={preview} 
            alt="Preview" 
            className="w-full h-full object-contain p-4" 
          />
          <button
            onClick={clearFile}
            className="absolute top-2 right-2 p-1.5 bg-black/50 hover:bg-black/70 rounded-full text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
          <div className="absolute bottom-0 left-0 right-0 bg-black/60 p-2 text-center text-white text-xs truncate">
            {fileName}
          </div>
        </div>
      ) : fileName ? (
        <div className="flex flex-col items-center gap-3 p-6 text-center">
          <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center text-primary">
            <FileAudio className="w-8 h-8" />
          </div>
          <div>
            <p className="font-medium">{fileName}</p>
            <p className="text-xs text-muted-foreground mt-1">Click to change file</p>
          </div>
        </div>
      ) : (
        <div className="flex flex-col items-center gap-3 p-6 text-center">
          <div className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center text-muted-foreground group-hover:text-primary group-hover:scale-110 transition-all duration-200">
            <Icon className="w-6 h-6" />
          </div>
          <div>
            <p className="font-medium text-foreground">{label}</p>
            <p className="text-xs text-muted-foreground mt-1">
              Drag & drop or click to browse
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
