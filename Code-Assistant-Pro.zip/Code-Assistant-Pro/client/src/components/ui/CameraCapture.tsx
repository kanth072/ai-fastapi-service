import { useRef, useState, useCallback, useEffect } from "react";
import { Camera, RefreshCw, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";

interface CameraCaptureProps {
  onCapture: (blob: Blob) => void;
}

export function CameraCapture({ onCapture }: CameraCaptureProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [isActive, setIsActive] = useState(false);

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: "user" } 
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
      setIsActive(true);
    } catch (err) {
      toast({
        title: "Camera Error",
        description: "Could not access camera. Please check permissions.",
        variant: "destructive",
      });
    }
  };

  const stopCamera = useCallback(() => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
      setIsActive(false);
    }
  }, [stream]);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, [stopCamera]);

  const takePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      
      const context = canvas.getContext('2d');
      if (context) {
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        canvas.toBlob((blob) => {
          if (blob) {
            onCapture(blob);
            stopCamera();
          }
        }, 'image/jpeg', 0.95);
      }
    }
  };

  if (!isActive) {
    return (
      <Button 
        onClick={startCamera}
        variant="outline"
        className="w-full h-32 flex flex-col gap-2 border-dashed border-2 hover:border-primary hover:bg-primary/5 transition-all group"
      >
        <Camera className="w-8 h-8 text-muted-foreground group-hover:text-primary transition-colors" />
        <span className="text-sm font-medium text-muted-foreground group-hover:text-primary">
          Open Camera
        </span>
      </Button>
    );
  }

  return (
    <div className="relative rounded-2xl overflow-hidden shadow-lg bg-black aspect-video">
      <video 
        ref={videoRef} 
        autoPlay 
        playsInline 
        className="w-full h-full object-cover"
      />
      <canvas ref={canvasRef} className="hidden" />
      
      <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-4">
        <Button 
          onClick={takePhoto}
          size="lg"
          className="rounded-full w-16 h-16 p-0 bg-white hover:bg-white/90 border-4 border-primary/50 shadow-xl"
        >
          <div className="w-12 h-12 rounded-full bg-primary" />
        </Button>
        
        <Button 
          onClick={stopCamera}
          variant="destructive"
          size="icon"
          className="rounded-full absolute right-4 bottom-2"
        >
          <X className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}
