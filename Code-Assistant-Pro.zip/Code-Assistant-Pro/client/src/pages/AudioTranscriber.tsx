import { Sidebar } from "@/components/layout/Sidebar";
import { MobileNav } from "@/components/layout/MobileNav";
import { FileUpload } from "@/components/ui/FileUpload";
import { Button } from "@/components/ui/button";
import { useTranscribeAudio } from "@/hooks/use-media";
import { Loader2, Mic, Copy, Check, FileAudio, Square, Play } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import { toast } from "@/hooks/use-toast";

export default function AudioTranscriber() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [transcription, setTranscription] = useState<{ text: string; language?: string } | null>(null);
  const [copied, setCopied] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const transcribeMutation = useTranscribeAudio();

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          chunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(chunksRef.current, { type: 'audio/webm' });
        const audioFile = new File([audioBlob], "recording.webm", { type: 'audio/webm' });
        setSelectedFile(audioFile);
        
        // Auto-transcribe recording
        const formData = new FormData();
        formData.append("audio", audioFile);
        performTranscription(formData);
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingTime(0);
      timerRef.current = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);

      toast({
        title: "Recording Started",
        description: "Speak clearly into your microphone.",
      });
    } catch (err) {
      toast({
        title: "Microphone Error",
        description: "Could not access your microphone. Please check permissions.",
        variant: "destructive",
      });
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
      setIsRecording(false);
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const performTranscription = (formData: FormData) => {
    transcribeMutation.mutate(formData, {
      onSuccess: (data) => {
        setTranscription({
          text: data.transcribed_text,
          language: data.language
        });
        toast({
          title: "Transcription Complete",
          description: "Audio has been successfully transcribed.",
        });
      },
      onError: (err) => {
        toast({
          title: "Transcription Failed",
          description: err.message,
          variant: "destructive",
        });
      },
    });
  };

  const handleTranscribe = () => {
    if (!selectedFile) return;
    const formData = new FormData();
    formData.append("audio", selectedFile);
    performTranscription(formData);
  };

  const handleCopy = () => {
    if (transcription?.text) {
      navigator.clipboard.writeText(transcription.text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      toast({
        title: "Copied to clipboard",
      });
    }
  };

  return (
    <div className="min-h-screen bg-secondary/30">
      <Sidebar />
      <div className="md:ml-64 min-h-screen flex flex-col">
        <MobileNav />
        
        <main className="flex-1 p-4 md:p-8 lg:p-12 max-w-5xl mx-auto w-full">
          <div className="mb-8">
            <h1 className="text-3xl font-bold font-display flex items-center gap-3">
              <span className="p-2 bg-purple-100 text-purple-600 rounded-lg dark:bg-purple-900/30 dark:text-purple-400">
                <Mic className="w-6 h-6" />
              </span>
              Audio Transcriber
            </h1>
            <p className="text-muted-foreground mt-2 ml-14">
              Upload audio files to convert speech into accurate text instantly.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-1 space-y-6">
              <div className="bg-card p-6 rounded-2xl border border-border shadow-sm">
                <div className="space-y-4">
                  <div className="flex flex-col gap-3">
                    <Button
                      onClick={isRecording ? stopRecording : startRecording}
                      variant={isRecording ? "destructive" : "outline"}
                      className={`w-full h-16 text-lg font-bold transition-all ${isRecording ? 'animate-pulse' : ''}`}
                    >
                      {isRecording ? (
                        <>
                          <Square className="w-6 h-6 mr-2 fill-current" />
                          Stop ({formatTime(recordingTime)})
                        </>
                      ) : (
                        <>
                          <Mic className="w-6 h-6 mr-2" />
                          Record from Mic
                        </>
                      )}
                    </Button>
                    
                    <div className="relative">
                      <div className="absolute inset-0 flex items-center">
                        <span className="w-full border-t" />
                      </div>
                      <div className="relative flex justify-center text-xs uppercase">
                        <span className="bg-card px-2 text-muted-foreground">Or upload file</span>
                      </div>
                    </div>

                    <FileUpload 
                      accept={{ 'audio/*': ['.mp3', '.wav', '.m4a', '.ogg'] }}
                      onFileSelect={setSelectedFile}
                      icon={FileAudio}
                      label="Select Audio File"
                    />
                  </div>
                </div>

                <Button
                  onClick={handleTranscribe}
                  disabled={!selectedFile || transcribeMutation.isPending || isRecording}
                  className="w-full mt-6 h-12 text-lg font-semibold bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 shadow-lg shadow-purple-500/20"
                >
                  {transcribeMutation.isPending ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Transcribing...
                    </>
                  ) : (
                    <>
                      <Mic className="w-5 h-5 mr-2" />
                      Start Transcription
                    </>
                  )}
                </Button>
              </div>

              <div className="bg-purple-50 dark:bg-purple-900/10 p-6 rounded-2xl border border-purple-100 dark:border-purple-900/20">
                <h3 className="font-semibold text-purple-900 dark:text-purple-100 mb-2">Supported Formats</h3>
                <p className="text-sm text-purple-800 dark:text-purple-200">
                  MP3, WAV, M4A, OGG. <br/>
                  Max file size: 25MB.
                </p>
              </div>
            </div>

            <div className="lg:col-span-2">
              <div className="bg-card rounded-2xl border border-border shadow-sm min-h-[500px] flex flex-col">
                <div className="p-6 border-b border-border flex items-center justify-between">
                  <h2 className="text-xl font-bold">Transcript</h2>
                  {transcription && (
                    <div className="flex items-center gap-3">
                      {transcription.language && (
                        <span className="px-3 py-1 bg-secondary rounded-full text-xs font-medium uppercase tracking-wider">
                          {transcription.language}
                        </span>
                      )}
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
                        {copied ? "Copied" : "Copy Text"}
                      </Button>
                    </div>
                  )}
                </div>

                <div className="p-6 flex-1 bg-secondary/10">
                  {transcribeMutation.isPending ? (
                    <div className="h-full flex flex-col items-center justify-center text-muted-foreground">
                      <Loader2 className="w-8 h-8 animate-spin mb-4 text-primary" />
                      <p>Listening and writing...</p>
                    </div>
                  ) : transcription ? (
                    <div className="prose dark:prose-invert max-w-none">
                      <p className="whitespace-pre-wrap leading-relaxed text-lg">
                        {transcription.text}
                      </p>
                    </div>
                  ) : (
                    <div className="h-full flex flex-col items-center justify-center text-muted-foreground opacity-50">
                      <Mic className="w-16 h-16 mb-4 stroke-1" />
                      <p className="text-lg">Upload audio to see transcript here</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
