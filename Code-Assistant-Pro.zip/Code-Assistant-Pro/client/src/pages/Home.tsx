import { Sidebar } from "@/components/layout/Sidebar";
import { MobileNav } from "@/components/layout/MobileNav";
import { useImages, useAudioTranscriptions } from "@/hooks/use-media";
import { 
  ArrowRight, 
  Camera, 
  Mic, 
  Sparkles, 
  Clock, 
  ShoppingCart, 
  Package, 
  TrendingUp, 
  Zap, 
  Tag 
} from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

function StatCard({ label, value, icon: Icon, colorClass, bgClass }: any) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card p-6 rounded-2xl border border-border/50 shadow-sm flex items-center gap-4 hover-elevate transition-all"
    >
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${bgClass} ${colorClass}`}>
        <Icon className="w-6 h-6" />
      </div>
      <div>
        <p className="text-sm font-medium text-muted-foreground">{label}</p>
        <h3 className="text-2xl font-bold font-display">{value}</h3>
      </div>
    </motion.div>
  );
}

function FeatureCard({ title, desc, href, icon: Icon, gradient, borderColor }: any) {
  return (
    <Link href={href}>
      <motion.div 
        whileHover={{ y: -4 }}
        className={`group cursor-pointer relative overflow-hidden bg-card rounded-2xl border-t-4 ${borderColor} p-8 shadow-sm hover:shadow-xl transition-all duration-300 h-full`}
      >
        <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${gradient} opacity-5 rounded-bl-[100px] transition-opacity group-hover:opacity-10`} />
        
        <div className="relative z-10">
          <div className="w-14 h-14 rounded-2xl bg-secondary flex items-center justify-center mb-6 group-hover:bg-primary group-hover:text-primary-foreground transition-colors duration-300">
            <Icon className="w-7 h-7" />
          </div>
          
          <h3 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors">{title}</h3>
          <p className="text-muted-foreground mb-6 line-clamp-2">
            {desc}
          </p>
          
          <div className="flex items-center text-sm font-bold text-primary opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300">
            LAUNCH TOOL <ArrowRight className="w-4 h-4 ml-2" />
          </div>
        </div>
      </motion.div>
    </Link>
  );
}

export default function Home() {
  const { data: images } = useImages();
  const { data: audio } = useAudioTranscriptions();

  const imageCount = images?.length || 0;
  const audioCount = audio?.length || 0;

  return (
    <div className="min-h-screen bg-secondary/30">
      <Sidebar />
      <div className="md:ml-64 min-h-screen flex flex-col">
        <MobileNav />
        
        <main className="flex-1 p-4 md:p-8 lg:p-12 max-w-7xl mx-auto w-full">
          {/* Hero Section */}
          <div className="mb-12">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 rounded-3xl p-8 md:p-12 text-white shadow-2xl relative overflow-hidden"
            >
              <div className="relative z-10 max-w-2xl">
                <span className="inline-flex items-center gap-2 px-3 py-1 bg-white/20 backdrop-blur-md rounded-full text-xs font-bold uppercase tracking-wider mb-6">
                  <Sparkles className="w-4 h-4" /> AI-Powered E-Commerce Suite
                </span>
                <h1 className="text-4xl md:text-5xl font-bold font-display leading-tight mb-6">
                  Boost Your Sales with Intelligent AI
                </h1>
                <p className="text-lg text-white/80 mb-8 leading-relaxed">
                  Transform product media, transcribe descriptions in any language to professional English, and optimize your storefront.
                </p>
                <div className="flex flex-wrap gap-4">
                  <Link href="/image-studio">
                    <Button size="lg" className="bg-white text-purple-600 hover:bg-white/90 font-bold h-12 shadow-lg">
                      Start Processing <ArrowRight className="ml-2 w-5 h-5" />
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -mr-20 -mt-20"></div>
            </motion.div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            <StatCard 
              label="Products" 
              value={imageCount} 
              icon={Package} 
              bgClass="bg-blue-100 dark:bg-blue-900/30"
              colorClass="text-blue-600 dark:text-blue-400" 
            />
            <StatCard 
              label="Sales Analysis" 
              value={audioCount} 
              icon={TrendingUp} 
              bgClass="bg-purple-100 dark:bg-purple-900/30"
              colorClass="text-purple-600 dark:text-purple-400" 
            />
            <StatCard 
              label="AI Credits" 
              value="Unlimited" 
              icon={Zap} 
              bgClass="bg-amber-100 dark:bg-amber-900/30"
              colorClass="text-amber-600 dark:text-amber-400" 
            />
            <StatCard 
              label="Cart Status" 
              value="Healthy" 
              icon={ShoppingCart} 
              bgClass="bg-emerald-100 dark:bg-emerald-900/30"
              colorClass="text-emerald-600 dark:text-emerald-400" 
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <FeatureCard
              title="Image Studio"
              desc="Upload product photos to generate 5 stunning AI variations instantly. Enhanced for conversion."
              href="/image-studio"
              icon={Camera}
              gradient="from-blue-500 to-cyan-500"
              borderColor="border-t-blue-500"
            />
            <FeatureCard
              title="Audio Transcriber"
              desc="Convert product pitches in any language to professional English reports with e-commerce formatting."
              href="/audio-transcriber"
              icon={Mic}
              gradient="from-purple-500 to-pink-500"
              borderColor="border-t-purple-500"
            />
          </div>
        </main>
      </div>
    </div>
  );
}
