import { Sidebar } from "@/components/layout/Sidebar";
import { MobileNav } from "@/components/layout/MobileNav";
import { useImages, useAudioTranscriptions } from "@/hooks/use-media";
import { Loader2, Calendar, FileText, Image as ImageIcon } from "lucide-react";
import { format } from "date-fns";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

function ImageHistoryItem({ item }: any) {
  // item.variations is generated_images array
  const variations = (item.variations as string[]) || [];
  
  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow">
      <div className="aspect-video bg-secondary relative overflow-hidden group">
        {/* Only showing first variation as thumbnail */}
        {variations[0] && (
          <img 
            src={variations[0]} 
            alt="Processed result" 
            className="w-full h-full object-cover"
          />
        )}
        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
           <span className="text-white font-medium">{variations.length} Variations</span>
        </div>
      </div>
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Calendar className="w-4 h-4" />
            {item.createdAt ? format(new Date(item.createdAt), 'MMM d, yyyy') : 'Just now'}
          </div>
          <Badge variant="secondary">Success</Badge>
        </div>
      </CardContent>
    </Card>
  );
}

function AudioHistoryItem({ item }: any) {
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <p className="font-medium">Transcription</p>
              <p className="text-xs text-muted-foreground">
                {item.createdAt ? format(new Date(item.createdAt), 'MMM d, yyyy • h:mm a') : 'Just now'}
              </p>
            </div>
          </div>
          {item.language && (
            <Badge variant="outline" className="uppercase">{item.language}</Badge>
          )}
        </div>
        
        <p className="text-muted-foreground line-clamp-3 text-sm leading-relaxed bg-secondary/30 p-3 rounded-lg">
          {item.transcribedText}
        </p>
      </CardContent>
    </Card>
  );
}

export default function History() {
  const { data: images, isLoading: imagesLoading } = useImages();
  const { data: audio, isLoading: audioLoading } = useAudioTranscriptions();

  const isLoading = imagesLoading || audioLoading;

  return (
    <div className="min-h-screen bg-secondary/30">
      <Sidebar />
      <div className="md:ml-64 min-h-screen flex flex-col">
        <MobileNav />
        
        <main className="flex-1 p-4 md:p-8 lg:p-12 max-w-7xl mx-auto w-full">
          <div className="mb-8">
            <h1 className="text-3xl font-bold font-display">History</h1>
            <p className="text-muted-foreground mt-2">
              View your past generations and transcriptions.
            </p>
          </div>

          <Tabs defaultValue="images" className="w-full">
            <TabsList className="mb-8 w-full sm:w-auto">
              <TabsTrigger value="images" className="flex-1 sm:flex-none">Images</TabsTrigger>
              <TabsTrigger value="audio" className="flex-1 sm:flex-none">Audio</TabsTrigger>
            </TabsList>

            {isLoading ? (
              <div className="flex justify-center py-20">
                <Loader2 className="w-10 h-10 animate-spin text-primary" />
              </div>
            ) : (
              <>
                <TabsContent value="images" className="mt-0">
                  {images && images.length > 0 ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                      {images.map((item) => (
                        <ImageHistoryItem key={item.id} item={item} />
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-20 bg-card rounded-2xl border border-border border-dashed">
                      <ImageIcon className="w-12 h-12 mx-auto text-muted-foreground mb-4 opacity-50" />
                      <h3 className="text-lg font-medium">No images yet</h3>
                      <p className="text-muted-foreground">Start by visiting the Image Studio.</p>
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="audio" className="mt-0">
                  {audio && audio.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {audio.map((item) => (
                        <AudioHistoryItem key={item.id} item={item} />
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-20 bg-card rounded-2xl border border-border border-dashed">
                      <FileText className="w-12 h-12 mx-auto text-muted-foreground mb-4 opacity-50" />
                      <h3 className="text-lg font-medium">No transcriptions yet</h3>
                      <p className="text-muted-foreground">Start by visiting the Audio Transcriber.</p>
                    </div>
                  )}
                </TabsContent>
              </>
            )}
          </Tabs>
        </main>
      </div>
    </div>
  );
}
