import { Sidebar } from "@/components/layout/Sidebar";
import { MobileNav } from "@/components/layout/MobileNav";
import { CameraCapture } from "@/components/ui/CameraCapture";
import { FileUpload } from "@/components/ui/FileUpload";
import { Button } from "@/components/ui/button";
import { useProcessImage } from "@/hooks/use-media";
import { Loader2, Sparkles, Download, Image as ImageIcon } from "lucide-react";
import { useState } from "react";
import { toast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion, AnimatePresence } from "framer-motion";

export default function ImageStudio() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [capturedBlob, setCapturedBlob] = useState<Blob | null>(null);
  const [results, setResults] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState("upload");

  const processMutation = useProcessImage();

  const handleCapture = (blob: Blob) => {
    setCapturedBlob(blob);
    setSelectedFile(null); // Clear file if capture exists
    handleProcess(blob, "captured-image.jpg");
  };

  const handleFileSelect = (file: File) => {
    setSelectedFile(file);
    setCapturedBlob(null); // Clear capture if file exists
  };

  const handleProcess = (blobOrFile: Blob | File, filename?: string) => {
    const formData = new FormData();
    // Ensure we append with a filename if it's a blob
    if (blobOrFile instanceof File) {
      formData.append("image", blobOrFile);
    } else {
      formData.append("image", blobOrFile, filename || "image.jpg");
    }

    processMutation.mutate(formData, {
      onSuccess: (data) => {
        setResults(data.generated_images);
        toast({
          title: "Processing Complete",
          description: "Your AI variations are ready!",
        });
      },
      onError: (err) => {
        toast({
          title: "Processing Failed",
          description: "Camera capture is currently disabled or failed. Please try uploading a file instead.",
          variant: "destructive",
        });
      },
    });
  };

  const triggerProcess = () => {
    if (selectedFile) handleProcess(selectedFile);
    else if (capturedBlob) {
        toast({
            title: "Camera Capture Disabled",
            description: "Direct camera capture is currently not supported. Please upload a photo.",
            variant: "destructive"
        });
    }
  };

  return (
    <div className="min-h-screen bg-secondary/30">
      <Sidebar />
      <div className="md:ml-64 min-h-screen flex flex-col">
        <MobileNav />
        
        <main className="flex-1 p-4 md:p-8 lg:p-12 max-w-6xl mx-auto w-full">
          <div className="mb-8">
            <h1 className="text-3xl font-bold font-display flex items-center gap-3">
              <span className="p-2 bg-blue-100 text-blue-600 rounded-lg dark:bg-blue-900/30 dark:text-blue-400">
                <ImageIcon className="w-6 h-6" />
              </span>
              Image Studio
            </h1>
            <p className="text-muted-foreground mt-2 ml-14">
              Capture or upload an image to generate stunning AI variations.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Input Section */}
            <div className="lg:col-span-1 space-y-6">
              <div className="bg-card p-6 rounded-2xl border border-border shadow-sm">
                <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                  <TabsList className="grid w-full grid-cols-2 mb-6">
                    <TabsTrigger value="upload">Upload</TabsTrigger>
                    <TabsTrigger value="camera">Camera</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="upload" className="mt-0">
                    <FileUpload 
                      accept={{ 'image/*': ['.png', '.jpg', '.jpeg', '.webp'] }}
                      onFileSelect={handleFileSelect}
                      icon={ImageIcon}
                      label="Upload Photo"
                    />
                  </TabsContent>
                  
                  <TabsContent value="camera" className="mt-0">
                    <div className="p-8 border-2 border-dashed border-border rounded-xl flex flex-col items-center justify-center text-center">
                        <div className="w-16 h-16 bg-red-100 text-red-600 rounded-full flex items-center justify-center mb-4">
                            <ImageIcon className="w-8 h-8" />
                        </div>
                        <h3 className="font-bold text-lg mb-2">Camera Disabled</h3>
                        <p className="text-muted-foreground text-sm max-w-[200px]">
                            Direct camera capture is currently unavailable. Please use the upload feature.
                        </p>
                    </div>
                  </TabsContent>
                </Tabs>

                <div className="mt-6">
                  <Button
                    onClick={triggerProcess}
                    disabled={(!selectedFile && !capturedBlob) || processMutation.isPending}
                    className="w-full h-12 text-lg font-semibold bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 shadow-lg shadow-blue-500/20"
                  >
                    {processMutation.isPending ? (
                      <>
                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5 mr-2" />
                        Generate Variations
                      </>
                    )}
                  </Button>
                </div>
              </div>

              {/* Tips Card */}
              <div className="bg-blue-50 dark:bg-blue-900/10 p-6 rounded-2xl border border-blue-100 dark:border-blue-900/20">
                <h3 className="font-semibold text-blue-900 dark:text-blue-100 mb-2">Pro Tips</h3>
                <ul className="text-sm text-blue-800 dark:text-blue-200 space-y-2 list-disc pl-4">
                  <li>Use well-lit photos for better results</li>
                  <li>Avoid blurry or low-resolution images</li>
                  <li>Center the subject in the frame</li>
                </ul>
              </div>
            </div>

            {/* Results Section */}
            <div className="lg:col-span-2">
              <div className="bg-card rounded-2xl border border-border shadow-sm min-h-[600px] p-6">
                <h2 className="text-xl font-bold mb-6">Generated Variations</h2>
                
                {processMutation.isPending ? (
                  <div className="h-[400px] flex flex-col items-center justify-center text-muted-foreground animate-pulse">
                    <div className="w-16 h-16 rounded-full bg-secondary mb-4 flex items-center justify-center">
                      <Loader2 className="w-8 h-8 animate-spin text-primary" />
                    </div>
                    <p>AI is working its magic...</p>
                  </div>
                ) : results.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <AnimatePresence>
                      {results.map((url, idx) => (
                        <motion.div
                          key={url}
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: idx * 0.1 }}
                          className="group relative aspect-square rounded-xl overflow-hidden bg-secondary"
                        >
                          {/* Use Unsplash mock if real URL fails or for demo, 
                              but in real app this would be the actual generated URL */}
                          <img 
                            src={url} 
                            alt={`Variation ${idx + 1}`}
                            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                          />
                          <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-2">
                            <Button size="sm" variant="secondary" onClick={() => window.open(url, '_blank')}>
                              <Download className="w-4 h-4 mr-2" />
                              Save
                            </Button>
                          </div>
                        </motion.div>
                      ))}
                    </AnimatePresence>
                  </div>
                ) : (
                  <div className="h-[400px] flex flex-col items-center justify-center text-muted-foreground border-2 border-dashed border-border rounded-xl">
                    <ImageIcon className="w-12 h-12 mb-4 opacity-20" />
                    <p>No variations generated yet</p>
                    <p className="text-sm opacity-60">Upload an image to get started</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
