## Packages
framer-motion | For smooth page transitions and micro-interactions
lucide-react | Beautiful icons
clsx | Utility for conditional classes
tailwind-merge | Utility for merging tailwind classes

## Notes
- Frontend must handle camera access via navigator.mediaDevices.getUserMedia
- Image processing expects FormData with 'image' field
- Audio transcription expects FormData with 'audio' field
- Images returned are URLs (assumed stored/served by backend or external service)
