# MediaMind - AI Processing Suite

## Overview

MediaMind is an AI-powered web application that provides three core features: Image Processing (with automatic variation generation), Audio-to-Text Transcription (using OpenAI Whisper), and live Camera Integration. The app uses a hybrid architecture where a Node.js/Express server acts as an API gateway and process manager, while a Python/FastAPI microservice handles the actual AI processing (image manipulation via OpenCV/Pillow, audio transcription via Whisper).

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend (React + Vite)
- **Location**: `client/` directory
- **Framework**: React with TypeScript, bundled by Vite
- **Routing**: Uses `wouter` for client-side routing with 4 pages: Home (dashboard), ImageStudio, AudioTranscriber, History
- **State Management**: TanStack React Query for server state, with custom hooks in `client/src/hooks/use-media.ts`
- **UI Components**: shadcn/ui component library (Radix UI primitives + Tailwind CSS), stored in `client/src/components/ui/`
- **Styling**: Tailwind CSS with CSS variables for theming (light/dark support), custom fonts (Inter, Outfit)
- **Animations**: Framer Motion for page transitions and micro-interactions
- **Media Access**: Browser `navigator.mediaDevices.getUserMedia` for camera capture and audio recording
- **Path Aliases**: `@/` maps to `client/src/`, `@shared/` maps to `shared/`

### Backend - Node.js API Gateway
- **Location**: `server/` directory
- **Framework**: Express.js with TypeScript, run via `tsx`
- **Role**: Acts as the API gateway — receives requests from the frontend, forwards file uploads to the Python microservice, and manages database operations
- **File Uploads**: Uses `multer` middleware, files stored temporarily in `uploads/` directory
- **API Routes** (defined in `server/routes.ts`):
  - `POST /api/images/process` — Accepts image upload, forwards to Python service at `http://127.0.0.1:5001/process/image`
  - `POST /api/audio/transcribe` — Accepts audio upload, forwards to Python service for Whisper transcription
  - `GET /api/images` — Lists processed images from database
  - `GET /api/audio` — Lists audio transcriptions from database
- **Retry Logic**: The Node gateway retries connections to the Python service (up to 5 times with 1-second delays) to handle startup timing
- **Process Management**: The Node server spawns the Python FastAPI process as a child process

### Backend - Python AI Microservice
- **Location**: `server/processing.py`
- **Framework**: FastAPI with Uvicorn, runs on port 5001
- **Image Processing**: Uses OpenCV (`opencv-python-headless`) and Pillow for generating 5 image variations:
  - Left/right angle perspective warping
  - Zoomed portrait crop
  - Background blur (portrait effect)
  - Light enhancement (contrast + brightness)
- **Audio Transcription**: Uses OpenAI Whisper (local model, not API) for speech-to-text with automatic language detection
- **Dependencies**: Listed in `server/requirements.txt` — fastapi, uvicorn, opencv-python-headless, pillow, numpy, openai-whisper, python-multipart, torch (via whisper), FFmpeg (system dependency)
- **CORS**: Enabled for all origins to allow communication from the Node gateway

### Shared Code
- **Location**: `shared/` directory
- **Schema** (`shared/schema.ts`): Drizzle ORM table definitions for PostgreSQL
  - `processed_images` table: id, original_url, variations (JSONB), created_at
  - `audio_transcriptions` table: id, audio_url, transcribed_text, language, created_at
- **API Contracts** (`shared/routes.ts`): Zod schemas defining request/response types for all API endpoints, used by both frontend and backend for type safety

### Database
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Connection**: Via `DATABASE_URL` environment variable, using `pg` Pool
- **Migrations**: Drizzle Kit with `drizzle-kit push` command (no migration files, direct push)
- **Storage Layer**: `server/storage.ts` provides a `DatabaseStorage` class implementing CRUD operations

### Build System
- **Development**: `npm run dev` runs `tsx server/index.ts` which starts both the Express server and Vite dev server (with HMR)
- **Production Build**: `npm run build` runs `script/build.ts` which uses Vite to build the client and esbuild to bundle the server
- **Production Serve**: `npm start` runs the built `dist/index.cjs`, serving static files from `dist/public/`

### Data Flow
1. User uploads image/audio or captures from camera in the browser
2. Frontend sends FormData to the Express API gateway
3. Express saves file temporarily via multer, then forwards it to the Python FastAPI microservice
4. Python processes the file (OpenCV for images, Whisper for audio) and returns results
5. Express saves metadata to PostgreSQL via Drizzle ORM and returns the response to the frontend
6. Images are returned as base64-encoded data URLs

## External Dependencies

### Required Services
- **PostgreSQL Database**: Required. Connection via `DATABASE_URL` environment variable. Used for persisting processed image metadata and audio transcription records.
- **FFmpeg**: System-level dependency required by OpenAI Whisper for audio file processing. Must be installed on the system.

### Python Packages (server/requirements.txt)
- `fastapi` + `uvicorn` — Python web framework and ASGI server
- `opencv-python-headless` (<4.10) — Image processing without GUI dependencies
- `pillow` — Image manipulation library
- `numpy` (<2.0) — Numerical computing
- `openai-whisper` — Local speech-to-text model (downloads models on first use)
- `python-multipart` — File upload handling for FastAPI
- `numba` — JIT compilation (Whisper dependency)

### Key Node.js Packages
- `express` — HTTP server framework
- `drizzle-orm` + `drizzle-kit` — Database ORM and migration tooling
- `multer` — File upload middleware
- `axios` — HTTP client for proxying requests to Python service
- `@tanstack/react-query` — Server state management
- `wouter` — Client-side routing
- `framer-motion` — Animation library
- `react-dropzone` — Drag-and-drop file upload component
- Radix UI primitives — Accessible UI component primitives (via shadcn/ui)

### Environment Variables
- `DATABASE_URL` — PostgreSQL connection string (required)
- `NODE_ENV` — Set to `development` or `production`